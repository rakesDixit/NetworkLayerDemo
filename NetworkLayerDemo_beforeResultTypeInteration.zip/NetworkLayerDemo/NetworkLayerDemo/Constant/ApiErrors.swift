//
//  ApiErrors.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 05/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation


import Foundation

public enum APIErrors: LocalizedError {
  case noInternetConnection
  case requestTimeout
  case jsonConversionFailure
  case unknown
  case custom(String)
  case noContent
  case incorrectPassword
  case serverError(Int, String)

  public var errorDescription: String? {
    switch self {
    case .noInternetConnection:
      return "No Internet Connection"
        //"label_no_internet_connection".localized
    case .requestTimeout:
      return "The request timed out."
        //"label_request_timed_out".localized
    case .unknown:
      return "Something went wrong"
    case .jsonConversionFailure: return "JSON Conversion Failure"
        //"label_json_conversion_failure".localized
    case .custom(let errorMessage): return errorMessage
    case .serverError(_, let errorMessage): return errorMessage
    case .noContent: return "Data Not Found"
        //"label_data_not_found".localized
    case .incorrectPassword: return "The current password you entered does not match our files."
    }
  }

  public var errorTitle: String {
    switch self {
    case .incorrectPassword:
      return "Incorrect Password!"
    default:
      return "Error"
        //"label_error".localized
    }
  }

}
