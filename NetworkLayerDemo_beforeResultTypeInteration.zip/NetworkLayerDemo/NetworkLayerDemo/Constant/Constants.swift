//
//  Constants.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 04/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation
import UIKit

typealias APICallback = (_ success: Bool, _ error: APIErrors?) -> Void
typealias Action = (() -> Void)
typealias AlertAction = (title: String, action: Action)
typealias Selection = ((Bool?, AnyObject?, Any?) -> Void)?
typealias DataMgrCallback = (_ result: Any?) -> Void
typealias TextFieldClosure = (_ textField: UITextField) -> Void
typealias StepperValueCallback = (_ value: Int) -> Void
typealias ValueCallback = (_ value: String) -> Void


struct Constants {
    static let AuthToken = "AuthToken"
}
