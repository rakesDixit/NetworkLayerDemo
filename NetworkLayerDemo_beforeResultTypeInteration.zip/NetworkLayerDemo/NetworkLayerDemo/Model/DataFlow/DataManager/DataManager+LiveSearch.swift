//
//  DataManager+LiveSearch.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 05/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation


import Foundation

extension DataManager {

  func searchEmployee(_ requestModel: LiveRequestModel, completion: @escaping DataMgrCallback) {
    /// Get data from server
    AlamoInterface().searchEmployee(requestModel) { (response) in
      if let responseModel = response as? [SearchModel] {
        Logger.log.info(responseModel)
        completion(response)
      } else if let error = response as? APIErrors {
        completion(error)
      } else {
        completion(APIErrors.unknown)
      }
    }
  }
}
