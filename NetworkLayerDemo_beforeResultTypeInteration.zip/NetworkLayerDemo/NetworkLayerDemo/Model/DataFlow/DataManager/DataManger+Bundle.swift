//
//  DataManger+Bundle.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 05/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation


class DataManager{
    
}

extension DataManager{
    /// get all available bundle type
    func getBundleType(completion: @escaping DataMgrCallback) {

      /// 1. From Request Manager
      AlamoInterface().getBundleType { (response) in
        if let bundleListobj = response as? BundleTypesListModel {
            print(bundleListobj)
         /* let realmInterface = RealmDBInterface()
          realmInterface.deleteObjects(object: BundleTypesListModel.self)
          realmInterface.addObject(object: store) */
          completion(response)
        } else if let error = response as? APIErrors {
          completion(error)
        } else {
          completion(APIErrors.unknown)
        }
      }
    }
}

