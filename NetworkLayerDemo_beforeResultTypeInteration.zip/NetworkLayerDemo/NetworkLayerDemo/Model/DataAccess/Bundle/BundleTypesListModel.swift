//
//  BundleTypesListModel.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 05/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation


struct BundleTypesListModel : Codable {

        let bundleTypesList : [BundleTypesList]?
        let countBundleTypes : Int?
        let errorDescription : String?
        let returnCode : Int?

        enum CodingKeys: String, CodingKey {
                case bundleTypesList = "bundleTypesList"
                case countBundleTypes = "countBundleTypes"
                case errorDescription = "errorDescription"
                case returnCode = "returnCode"
        }
    
        init(from decoder: Decoder) throws {
                let values = try decoder.container(keyedBy: CodingKeys.self)
                bundleTypesList = try values.decodeIfPresent([BundleTypesList].self, forKey: .bundleTypesList)
                countBundleTypes = try values.decodeIfPresent(Int.self, forKey: .countBundleTypes)
                errorDescription = try values.decodeIfPresent(String.self, forKey: .errorDescription)
                returnCode = try values.decodeIfPresent(Int.self, forKey: .returnCode)
        }

}

//MARK:- BundleTypesList Model
//MARK:-

struct BundleTypesList : Codable {

        let bundleType : String?
        let bundleTypeId : String?

        enum CodingKeys: String, CodingKey {
                case bundleType = "bundleType"
                case bundleTypeId = "bundleTypeId"
        }
    
        init(from decoder: Decoder) throws {
                let values = try decoder.container(keyedBy: CodingKeys.self)
                bundleType = try values.decodeIfPresent(String.self, forKey: .bundleType)
                bundleTypeId = try values.decodeIfPresent(String.self, forKey: .bundleTypeId)
        }

}

