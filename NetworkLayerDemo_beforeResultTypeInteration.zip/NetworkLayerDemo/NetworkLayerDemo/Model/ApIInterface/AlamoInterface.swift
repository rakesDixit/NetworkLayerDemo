//
//  AlamoInterface.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 04/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation
import Alamofire


class AlamoInterface {
    
    //MARK:- methods to fetch bundles
    //MARK:-
    
    func getBundleType(completion: @escaping DataMgrCallback) {
      BundleTypeRequestManager().getBundleType(completion: completion)
    }
    
    //for fetching Live Data
    func searchEmployee(_ requestModel: LiveRequestModel, completion: @escaping DataMgrCallback) {
        LiveSearchRequestMgr().searchEmployee(requestModel, completion: completion)
    }

}
