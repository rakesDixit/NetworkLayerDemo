//
//  APIManager.swift
//  SGS-iOS
//
//  Created by Yogesh on 6/15/17.
//  Copyright © 2017 DMI. All rights reserved.
//

import Foundation
import Alamofire

//Declare all request method here
protocol APIManagerProtocol {

//  @discardableResult
  @discardableResult
  func getMockData<T: Decodable>(fileName: String,
                                 responseModelType: T.Type,
                                 completion: @escaping (Result<T>) -> Void) -> APIRequest?

 

  // MARK: - Bundle
  @discardableResult
  func getBundleType(completion: @escaping (Result<BundleTypesListModel>) -> Void) -> APIRequest?
    
    // MARK: - searchEmployee
       @discardableResult
       func searchEmployee(requestModel: LiveRequestModel,
                           completion: @escaping (Result<[SearchModel]>) -> Void) -> APIRequest?

//  @discardableResult
//  func getBundleCategories(completion: @escaping (Result<BundleCategoriesListModel>) -> Void) -> APIRequest?
//
//  @discardableResult
//  func getAllBundles(completion: @escaping (Result<[BundleServerModel]>) -> Void) -> APIRequest?


}

 
class APIManager: APIManagerProtocol {

  let core: APIManagerCoreProtocol

  init(configuration: ConfigurationProtocol = Configuration(),
       core: APIManagerCoreProtocol? = nil) {
    if let core = core {
      self.core = core
    } else {
      self.core = APIManagerCore(configuration: configuration)
    }
  }
}
