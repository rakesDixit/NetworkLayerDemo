//
//  APIManagerCore.swift
//  SGS-iOS
//
//  Created by Yogesh on 6/15/17.
//  Copyright © 2017 DMI. All rights reserved.
//

import Foundation
import Alamofire
//import SwiftyJSON

class APIManagerCore: APIManagerCoreProtocol {
    fileprivate let networkManager: Alamofire.Session /// Network Manager for making API Request
  fileprivate let baseURL: URL /// base url of request
  fileprivate let configuration: ConfigurationProtocol /// API request configuration

  init(configuration: ConfigurationProtocol) {
    self.configuration = configuration
    baseURL = URL(string: configuration.baseURL)!
    networkManager = Alamofire.Session.default
  }

  /// This method is used to make API Request
  ///
  /// - Parameters:
  ///   - requestBuilder: which contains all the information of about the request
  ///   - responseParser: To Parse the server raw data
  /// - Returns: object of request which can be used to cancel the request
  @discardableResult
  func performRequest(requestBuilder: RequestBuilderProtocol,
                      responseParser: ResponseParserProtocol) -> APIRequest? {

    /// Check for network connection, if not reachable return with error
//    if ReachabilityManager.sharedInstance.isReachable() == false {
//      responseParser.handleError(error: APIErrors.noInternetConnection)
//      return nil
//    }

    /// Get the information from Request Builder
    let url = URL(string: requestBuilder.path, relativeTo: baseURL)!
    let method = requestBuilder.almofireRequestMethod
    let parameters = requestBuilder.parameters
    let encoding = requestBuilder.encoding
    //let headers = requestBuilder.headers
    let contentType = requestBuilder.headers?["Content-type"] ?? ""

    /// Generate a string object to print request information
    let requestMessage = printRequest(requestBuilder: requestBuilder)
    let headers : HTTPHeaders = [
        "Authorization": "Basic MY-API-KEY",
        "Content-Type" : contentType
        //"application/x-www-form-urlencoded"
    ]

    
    //headers to HTTPHeaders
   // RequestHeader to HTTPHeaders
    
    
    
    let dataRequest = networkManager.request(url,
                                             method: method,
                                             parameters: parameters,
                                             encoding: encoding,
                                             headers: headers)
    

    .validate()

    dataRequest.responseData { (response) in
      debugPrint("Response of URL \(url), method \(method), parameters \(String(describing: parameters))")
      switch response.result {
      case .success(let data):
        responseParser.parse(data: data, response: response.response)
      case .failure(let error):
        let errorMessage = "\(error)"
        Logger.log.info("⚠️ \(requestMessage) failed:\n" + errorMessage)
        if let responseData = response.data {
          debugPrint("Error Data \(String(describing: String.init(data: responseData, encoding: .utf8)))")
        }

        if (error as NSError).code == NSURLErrorTimedOut {
          responseParser.handleError(error: APIErrors.requestTimeout)
        } else {
          if let responseData = response.data,
            let message = String(data: responseData, encoding: .utf8),
            message.isEmptyString() == false {
            let statusCode = response.response?.statusCode ?? 0
            let error = APIErrors.serverError(statusCode, message)
            responseParser.handleError(error: error)
          } else {
            let statusCode = response.response?.statusCode ?? 0
            let error = APIErrors.serverError(statusCode, "Something went wrong")
            responseParser.handleError(error: error)
          }
        }
      }
    }
    return dataRequest.request
  }

  @discardableResult
  func printRequest(requestBuilder: RequestBuilderProtocol) -> String {
    let url = URL(string: requestBuilder.path, relativeTo: baseURL)!
    let method = requestBuilder.almofireRequestMethod
    let parameters = requestBuilder.parameters
    var requestMessage = "\(method.rawValue.capitalized) \(url)"
    if let parameters = parameters {
      requestMessage += " params: \(parameters)"
    } else {
      requestMessage += " params: []"
    }
    //Logger.log.info(requestMessage)
    return requestMessage
  }

  /// This method is used to make multi form data request
  ///
  /// - Parameters:
  ///   - requestBuilder: which contains all the information of about the request
  ///   - responseParser: To Parse the server raw data
  func performUploadRequest(requestBuilder: MultipartFormRequestBuilderProtocol,
                            responseParser: ResponseParserProtocol) {}
}

// MARK: - RequestBuilderProtocol Alamo extension
extension RequestBuilderProtocol {
  var almofireRequestMethod: HTTPMethod{
//   if let method = HTTPMethod(rawValue: self.method.rawValue) {
//      return method
//    }
     let method = HTTPMethod(rawValue: self.method.rawValue)
    //return .get
    return  method
  }
}
