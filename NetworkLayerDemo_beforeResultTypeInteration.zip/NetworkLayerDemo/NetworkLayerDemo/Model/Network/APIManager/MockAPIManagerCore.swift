//
//  MockAPIManagerCore.swift
//  HondaCommunityApp
//
//  Created by Yogesh Kr Singh on 12/03/18.
//  Copyright © 2018 Yogesh Kr Singh. All rights reserved.
//

import Foundation
import Alamofire

class MockAPIManagerCore: APIManagerCoreProtocol {

  func performRequest(requestBuilder: RequestBuilderProtocol, responseParser: ResponseParserProtocol) -> APIRequest? {

    guard let fileName = requestBuilder.path.split(separator: "/").last else {
      responseParser.handleError(error: .unknown)
      return nil
    }

    guard let filePath = Bundle.main.url(forResource: String(fileName), withExtension: "json") else {
      responseParser.handleError(error: .unknown)
      return nil
    }

    Logger.log.info("--> starting bg thread")
    DispatchQueue.global(qos: .background).async {
      do {
        Logger.log.info("--> inside bg thread")
        let jsonData = try Data.init(contentsOf: filePath)
        Logger.log.info("--> got data")
        DispatchQueue.main.async {
          Logger.log.info("--> inside main, parsing start")
          responseParser.parse(data: jsonData, response: nil)
        }
      } catch let error {
        DispatchQueue.main.async {
          responseParser.handleError(error: .unknown)
        }
        Logger.log.error("error while converting file contents into Data \(error)")
      }
    }
    return nil
  }

  func performUploadRequest(requestBuilder: MultipartFormRequestBuilderProtocol,
                            responseParser: ResponseParserProtocol) {
  }
}
