//
//  APIManageCoreProtocol.swift
//  HondaCommunityApp
//
//  Created by Yogesh Kr Singh on 12/03/18.
//  Copyright © 2018 Yogesh Kr Singh. All rights reserved.
//

import Foundation
import Alamofire

protocol APIManagerCoreProtocol {
  @discardableResult
  func performRequest(requestBuilder: RequestBuilderProtocol,
                      responseParser: ResponseParserProtocol) -> APIRequest?

  func performUploadRequest(requestBuilder: MultipartFormRequestBuilderProtocol,
                            responseParser: ResponseParserProtocol)
}
