//
//  APIPath.swift
//  SGS-iOS
//
//  Created by Yogesh on 7/6/17.
//  Copyright © 2017 DMI. All rights reserved.
//

import Foundation

struct APIPath {
  static let GetUSStatesList = "/api/getUSStatesList"
  static let SearchEmployee = "https://jsonplaceholder.typicode.com/posts"
   // https://jsonplaceholder.typicode.com/posts/10
    //"/api/employee/v1/employeeSearch"
    
}

struct APIParam {
  static let userId = "userId"
}

enum JSONFilePath: String {
  case storeList = "getGroceryStoresForZipcode"
  case bundleType = "getAllBundleTypes"
  case bundleCategories = "getAllBundleCategories"
  case bundles = "Bundles"
  case bundleIngredientMapping = "BundleIngredientMapping"
  case ingredients = "Ingredients"
  case ingredientTypes = "IngredientTypes"
  case measurementTypes = "MeasurementTypes"
  case getBundleCategoriesForAType = "getBundleCategoriesForAType"
  case ingredientSwap = "IngredientSwap"
  case detailedIngredientsInRecipe = "DetailedIngredientsInRecipe"
  case recipeForBundle = "RecipeForBundle"
}
