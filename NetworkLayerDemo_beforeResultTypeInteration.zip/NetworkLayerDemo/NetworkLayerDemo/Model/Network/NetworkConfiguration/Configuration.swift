//
//  Configuration.swift
//  SGS-iOS
//
//  Created by Yogesh on 6/15/17.
//  Copyright © 2017 DMI. All rights reserved.
//

//import DMIConfiguration
//
protocol ConfigurationProtocol {
  var baseURL: String { get }
}

struct Configuration: ConfigurationProtocol {
  //fileprivate let environment: DMIEnvironment

//  init(environment: DMIEnvironment = DMIEnvironment.sharedInstance) {
//    self.environment = environment
//  }

  var baseURL: String {
    return  "BaseURL"
  }
}


