//
//  NetworkConstants.swift
//  HondaCommunityApp
//
//  Created by Yogesh Kr Singh on 06/03/18.
//  Copyright © 2018 Yogesh Kr Singh. All rights reserved.
//

import Foundation

/// Define the parameter's dictionary
typealias ParametersDict = [String: Any]

typealias RequestHeader = [String: String]

typealias APIRequest = URLRequest

/// Define what kind of HTTP method must be used to carry out the `Request`
///
/// - get: get (no body is allowed inside)
/// - post: post
/// - put: put
/// - delete: delete
/// - patch: patch
enum RequestMethod: String {
  case get  = "GET"
  case post  = "POST"
  case put  = "PUT"
  case delete  = "DELETE"
  case patch  = "PATCH"
}

//Json EnCoding or URl Encoding enum here 


enum StatusCode: Int {
  case success = 200
  case noContent = 204
  case invalidCredential = 401
}
