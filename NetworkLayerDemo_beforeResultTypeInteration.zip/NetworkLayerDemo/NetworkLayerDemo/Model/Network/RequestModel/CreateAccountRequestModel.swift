//
//  CreateAccountRequestModel.swift
//  CampbellApp
//
//  Created by Yogesh Kr Singh on 21/11/18.
//  Copyright © 2018 DMI Innovation Pvt Ltd. All rights reserved.
//

import Foundation
//
//class CreateAccountRequestModel: RequestEncodable {
//  var firstName = ""
//  var lastName = ""
//  var emailId = ""
//  var password = ""
//  var zipCode = ""
//  var storeId = ""
//
//  var userId = "" // will require in edit user profile
//
//  convenience init(userContext: UserContext) {
//    self.init()
//    self.zipCode = userContext.zipCode ?? ""
//    self.storeId = userContext.selectedStore?.storeId ?? ""
//  }
//
//  func getUserModel() -> User {
//    let user = User()
//    user.firstName = self.firstName
//    user.lastName = self.lastName
//    user.emailId = self.emailId
//    user.password = self.password
//    user.zipCode = self.zipCode
//    user.storeId = self.storeId
//    return user
//  }
//}
