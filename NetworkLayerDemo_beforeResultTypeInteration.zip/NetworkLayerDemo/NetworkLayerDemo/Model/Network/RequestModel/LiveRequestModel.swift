//
//  LiveRequestModel.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 05/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation


struct LiveRequestModel: Codable {
    var text: String = ""
    
    init(text: String) {
        self.text = text
    }
}



class SearchModel: Codable {
    
    let userId : Int?
    let id : Int?
    let title : String?
    let body : String?
   // let completed : Bool?
    
   
    enum CodingKeys: String, CodingKey {
        
        case title = "title"
        case id = "id"
        case body = "body"
        case userId = "userId"
    }
    
    required init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        body = try values.decodeIfPresent(String.self, forKey: .body)
        userId = try values.decodeIfPresent(Int.self, forKey: .userId)
    }
}
