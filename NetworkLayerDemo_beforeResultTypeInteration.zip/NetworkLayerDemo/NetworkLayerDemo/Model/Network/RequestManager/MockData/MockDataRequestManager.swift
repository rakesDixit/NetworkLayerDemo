//
//  MockDataRequestManager.swift
//  HondaCommunityApp
//
//  Created by Yogesh Kr Singh on 22/05/18.
//  Copyright © 2018 Yogesh Kr Singh. All rights reserved.
//

import UIKit

class MockDataRequestManager {
  fileprivate let apiManager: APIManagerProtocol

  init(apiManager: APIManagerProtocol = APIManager(core: MockAPIManagerCore())) {
    self.apiManager = apiManager
  }

  func getMockData<T: Decodable>(fileName: String, responseModelType: T.Type, completion: @escaping DataMgrCallback) {
    apiManager.getMockData(fileName: fileName,
                           responseModelType: responseModelType) { (result) in
                            switch result {
                            case .success(let usStateList):
                              completion(usStateList)
                            case .failure(let error):
                              Logger.log.error(error)
                              completion(error)
                            }
    }
  }
}

extension APIManager {
  /**
   Method to perform request to get mock data

   - Returns: DataRequest that manages an underlying URLSessionDataTask
   **/
  func getMockData<T>(fileName: String,
                      responseModelType: T.Type,
                      completion: @escaping (Result<T>) -> Void) -> APIRequest? where T: Decodable {
    let requestBuilder = MockDataRequestBuilder(fileName)
    let responseBuilder = JSONDecodableResponseParser(completion)
    return core.performRequest(requestBuilder: requestBuilder, responseParser: responseBuilder)
  }

}

struct MockDataRequestBuilder: JSONRequestBuilderProtocol {

  var fileName: String

  init(_ fileName: String) {
    self.fileName = fileName
  }

  var path: String {
    return self.fileName
  }

  var method: RequestMethod {
    return .get
  }
}
