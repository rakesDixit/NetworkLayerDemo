//
//  BundleTypeRequestManager.swift
//  CampbellApp
//
//  Created by Yogesh Kr Singh on 28/11/18.
//  Copyright © 2018 DMI Innovation Pvt Ltd. All rights reserved.
//

import Foundation

class BundleTypeRequestManager {

  fileprivate let apiManager: APIManagerProtocol

  init(apiManager: APIManagerProtocol = APIManager(core: MockAPIManagerCore())) {
    self.apiManager = apiManager
  }

  func getBundleType(completion: @escaping DataMgrCallback) {
    apiManager.getBundleType { (result) in
      switch result {
      case .success(let response):
        completion(response)
      case .failure(let error):
        Logger.log.error(error)
        completion(error)
      }
    }
  }
}

extension APIManager {
  /**
   Method to perform request to get store List

   - Returns: DataRequest that manages an underlying URLSessionDataTask
   **/
  func getBundleType(completion: @escaping (Result<BundleTypesListModel>) -> Void) -> APIRequest? {
    let requestBuilder = BundleTypeRequestBuilder()
    let responseBuilder = JSONDecodableResponseParser(completion)
    return core.performRequest(requestBuilder: requestBuilder, responseParser: responseBuilder)
  }
}

struct BundleTypeRequestBuilder: URLQueryRequestBuilderProtocol {
  var path: String {
    return JSONFilePath.bundleType.rawValue
  }
}
