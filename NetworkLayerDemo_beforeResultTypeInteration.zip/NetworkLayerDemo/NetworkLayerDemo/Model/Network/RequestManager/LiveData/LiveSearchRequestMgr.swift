//
//  LiveSearchRequestMgr.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 05/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation
import Alamofire


import UIKit

class LiveSearchRequestMgr: NSObject {

  fileprivate let apiManager: APIManagerProtocol

  init(apiManager: APIManagerProtocol = APIManager()) {
    self.apiManager = apiManager
  }

  // search Employee
  func searchEmployee(_ requestModel: LiveRequestModel, completion: @escaping DataMgrCallback) {
    apiManager.searchEmployee(requestModel: requestModel) { (result) in
      switch result {
      case .success(let response):
        completion(response)
      case .failure(let error):
        Logger.log.error(error)
        completion(error)
      }
    }
  }
}

extension APIManager {

  // search Employee api
    func searchEmployee(requestModel: LiveRequestModel, completion: @escaping (Result<[SearchModel]>) -> Void) -> APIRequest? {
    let requestBuilder = SearchRequestBuilder(requestModel: requestModel)
    let responseBuilder = JSONDecodableResponseParser(completion)
    return core.performRequest(requestBuilder: requestBuilder, responseParser: responseBuilder)
  }

}

struct SearchRequestBuilder: URLQueryRequestBuilderProtocol {

  var requestModel: LiveRequestModel
  var parameter: ParametersDict!
    
    
  var path: String {
    return APIPath.SearchEmployee
  }

  var method: RequestMethod {
    return .get
  }

//  var parameters: ParametersDict? {
//    return ["/": requestModel.text]
//  }
    
    
//    var encoding: ParameterEncoding {
//      return URLEncoding.queryString
//    }
    
    var parameters: ParametersDict? {
      return nil
        //["/": requestModel.text]
    }

  var headers: RequestHeader? {
    return ["Content-type": "application/json"]
      //  ; charset=UTF-8"]
    // ["Authorization": "Bearer \(KeychainUtils.shared.getAccessToken())"]
  }
    
    /*

     


     


     
     */

}
