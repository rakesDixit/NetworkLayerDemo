//
//  RequestBuilderProtocol.swift
//  SGS-iOS
//
//  Created by Yogesh on 6/15/17.
//  Copyright © 2017 DMI. All rights reserved.
//

import Alamofire

enum FormdataType: Int {
  case text
  case file
}

protocol RequestBuilderProtocol {
  var path: String { get }
  var method: RequestMethod { get }
  var parameters: ParametersDict? { get }
  var encoding: ParameterEncoding { get }
  var headers: RequestHeader? { get }
}

/// json request
protocol JSONRequestBuilderProtocol: RequestBuilderProtocol { }

extension JSONRequestBuilderProtocol {

  var method: RequestMethod {
    return .get
  }

  var encoding: ParameterEncoding {
    return JSONEncoding.default
  }

  var parameters: ParametersDict? {
    return nil
  }

  var headers: RequestHeader? {
    return nil
  }
}

protocol URLQueryRequestBuilderProtocol: RequestBuilderProtocol { }

extension URLQueryRequestBuilderProtocol {
  var method: RequestMethod {
    return .get
  }

  var encoding: ParameterEncoding {
    return URLEncoding.default
  }

  var parameters: ParametersDict? {
    return nil
  }

  var headers: RequestHeader? {
    return nil
  }
}

protocol MultipartFormRequestBuilderProtocol: RequestBuilderProtocol {
  var multiformData: [MultipartFormRequest] { get }
}

/// multi part data
struct MultipartFormRequest {
  let data: Data
  let key: String
  let dataType: FormdataType
  let mimeType: String
  let fileName: String //in case of file FormdataType

  init(data: Data, key: String, dataType: FormdataType? = .text, mimeType: String? = "", fileName: String? = "") {
    self.data = data
    self.key = key
    self.dataType = dataType!
    self.mimeType = mimeType!
    self.fileName = fileName!
  }
}

extension MultipartFormRequestBuilderProtocol {
  // method
  var method: RequestMethod {
    return .post
  }

  // encoding
  var encoding: ParameterEncoding {
    return JSONEncoding.default
  }

  // parameters
  var parameters: ParametersDict? {
    return nil
  }
}

// MARK: - RequestEncodable
protocol RequestEncodable: Encodable {
  func getRequestParam() -> ParametersDict?
}

extension RequestEncodable {
  /// get request param
  func getRequestParam() -> ParametersDict? {
    do {
      let encoded = try JSONEncoder().encode(self)
      let requestData = try JSONSerialization.jsonObject(with: encoded, options: []) as? ParametersDict
      Logger.log.debug("request \(String(describing: requestData))")
      return requestData
    } catch let exception {
      Logger.log.error("Error while encoding \(self) with exception \(exception)")
    }
    return nil
  }
}
