//
//  ResponseParserProtocol.swift
//  SGS-iOS
//
//  Created by Yogesh on 6/15/17.
//  Copyright © 2017 DMI. All rights reserved.
//

import Foundation
//import RealmSwift
import SwiftyJSON

struct ResponseParserError {
  static let domain = "com.campbell.campbell"
  static let invalidResponse = 1
}

/// data response type
/// extend it to provide other data type support
enum DataResponseType {
  case json
  case empty
}

/// Implement this protocol for raw data parsing
protocol ResponseParserProtocol {
  var dataResponseType: DataResponseType { get }
  func parse(data: Any, response: HTTPURLResponse?)
  func handleError(error: APIErrors)
  func handleInvalidResponse(_ response: Any)
}



/// json request for JSON data type
protocol JSONResponseParserProtocol: ResponseParserProtocol {}


extension JSONResponseParserProtocol {

  var dataResponseType: DataResponseType {
    return .json
  }

  func handleInvalidResponse(_ response: Any) {
    Logger.log.info("Invalid response: \(response)")
    handleError(error: APIErrors.unknown)
  }

  /// Convert Data to JSON for raw response and print it on console
  func printJSONResponse(jsonData: Data) {
    do {
      let jsonString = try JSON(data: jsonData)
      Logger.log.info("--> json string \(jsonString)")
    } catch let error {
      Logger.log.error("--> Not able to print respons in JSON \(error)")
    }
  }

  func isValidJson(jsonData: Data, statusCode: Int) -> APIErrors? {
    do {
      let jsonString = try JSON(data: jsonData)
        Logger.log.info("--> json string \(jsonString)")
      return nil
    } catch let error {
      if statusCode == StatusCode.noContent.rawValue {
        return APIErrors.noContent
      }
      if statusCode == StatusCode.success.rawValue {
        if let responseInString = String(data: jsonData, encoding: .utf8) {
          return APIErrors.custom(responseInString)
        }
      }
      Logger.log.error("--> Not able to print respons in JSON \(error)")
    }
    return APIErrors.unknown
  }

  func parseBaseResponse (data: [String: Any]) -> (Int, String) {
    if let returnCode = data["returnCode"] as? Int,
      let errorDescription = data["errorDescription"] as? String {
      return (returnCode, errorDescription)
    }
    return (1, "")
  }
}

/// Using Decodable protocol for parsing model
/// Model must confirm Decodable protocol
struct JSONDecodableResponseParser<T: Decodable> : JSONResponseParserProtocol {

  let completion: (Result<T>) -> Void

  init(_ completion: @escaping (Result<T>) -> Void) {
    self.completion = completion
  }

  func parse(data: Any, response: HTTPURLResponse?) {

    /// Check for valid data type
    guard let jsonData = data as? Data else {
      handleInvalidResponse(data)
      return
    }

    let statusCode = response?.statusCode ?? 200
    /// check for valid json response
    if let error = isValidJson(jsonData: jsonData, statusCode: statusCode) {
      handleError(error: error)
      return
    }

    /// Use JSONDecode to parse the content
    let decoder = JSONDecoder()
    do {
        
      let responseModel = try decoder.decode(T.self, from: jsonData)
      completion(Result<T>.success(responseModel))
    } catch let error {
      Logger.log.error("error \(error)")
      handleInvalidResponse(jsonData)
    }
  }

  /// Handle error
  func handleError(error: APIErrors) {
    completion(Result<T>.failure(error))
  }
}
