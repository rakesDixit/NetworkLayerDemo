//
//  ViewController.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 04/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    //MARK:- @IB-Outlets
    //MARK:-
    
    @IBOutlet weak var mockApiBtn: UIButton! {
       didSet {
         mockApiBtn.isEnabled = true
         mockApiBtn.setTitle("Get Mock Data", for: .normal)
       }
     }
    
    @IBOutlet weak var liveApiBtn: UIButton! {
       didSet {
         liveApiBtn.isEnabled = true
         liveApiBtn.setTitle("Get Live Data", for: .normal)
       }
     }
    
    let viewModel = FetchMyApiViewModel()
    
    //MARK:- UI-View Life Cycle Methods
    //MARK:-
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
        
    //MARK:- @IB-Action Method
    //MARK:-
    
    @IBAction func mockApiBtnTapped(sender:UIButton){

        self.viewModel.getBundleType { [weak self](success, error) in
            if success == true {
                print(self?.viewModel.bundleTypes?.bundleTypesList?.count ?? 0)
            } else {
                print(error!)
            }
        }
    }
    
    
    @IBAction func liveApiBtnTapped(sender:UIButton){
        viewModel.fetchLiveApiData { [weak self](status, error) in
            if status == true {
                print(self?.viewModel.liveApiData?.count ?? 0)
            } else {
                //handle error here
                print("\(String(describing: error))")
            }
            
        }
       }
    
}

