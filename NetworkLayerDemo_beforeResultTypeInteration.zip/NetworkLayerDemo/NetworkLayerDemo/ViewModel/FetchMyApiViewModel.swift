//
//  FetchMyApiViewModel.swift
//  NetworkLayerDemo
//
//  Created by Rakesh dixit on 04/06/20.
//  Copyright © 2020 Rakesh dixit. All rights reserved.
//

import Foundation
import UIKit


class FetchMyApiViewModel: NSObject {
    
    var bundleTypes: BundleTypesListModel?
    var liveApiData: [SearchModel]?

    func getBundleType(completion: @escaping APICallback) {
       DataManager().getBundleType { [weak self] (response) in
      
         if let bundleTypes = response as? BundleTypesListModel {
            self?.bundleTypes = bundleTypes
           completion(true, nil)
         } else {
           //self?.handleErrorResponse(result: response, completion: completion)
         }
       }
     }
    
    
    //fetch live DATA
    func fetchLiveApiData(completion: @escaping APICallback) {
      let searchRequest = LiveRequestModel(text: "1")
      // api call
      DataManager().searchEmployee(searchRequest) { [weak self] (response) in
        if let result = response as? [SearchModel]{
          //let employees = result.data {
            self?.liveApiData = result
         // self?.searchResults = employees
            print(result)
          completion(true, nil)
        } else {
          completion(false, APIErrors.unknown)
        }
      }
    }
}


